﻿
namespace WetlandsNZ
{
    partial class Remove_Land_Use
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.lblReq = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.lblSHList = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.txtSHID = new System.Windows.Forms.TextBox();
            this.txtImpact = new System.Windows.Forms.TextBox();
            this.txtAID = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtSHName = new System.Windows.Forms.TextBox();
            this.txtSSatus = new System.Windows.Forms.TextBox();
            this.txtSName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblLUList = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtID = new System.Windows.Forms.TextBox();
            this.txtSID = new System.Windows.Forms.TextBox();
            this.listBox5 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // listBox3
            // 
            this.listBox3.FormattingEnabled = true;
            this.listBox3.ItemHeight = 19;
            this.listBox3.Location = new System.Drawing.Point(31, 264);
            this.listBox3.Margin = new System.Windows.Forms.Padding(4);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(360, 156);
            this.listBox3.TabIndex = 120;
            this.listBox3.SelectedIndexChanged += new System.EventHandler(this.listBox3_SelectedIndexChanged);
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 19;
            this.listBox2.Location = new System.Drawing.Point(793, 165);
            this.listBox2.Margin = new System.Windows.Forms.Padding(4);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(59, 23);
            this.listBox2.TabIndex = 119;
            // 
            // lblReq
            // 
            this.lblReq.AutoSize = true;
            this.lblReq.ForeColor = System.Drawing.Color.Red;
            this.lblReq.Location = new System.Drawing.Point(563, 402);
            this.lblReq.Name = "lblReq";
            this.lblReq.Size = new System.Drawing.Size(121, 19);
            this.lblReq.TabIndex = 117;
            this.lblReq.Text = "* Required Fields";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(832, 394);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 34);
            this.button1.TabIndex = 116;
            this.button1.Text = "Return";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(691, 394);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(133, 34);
            this.button2.TabIndex = 115;
            this.button2.Text = "Remove Land Use";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(395, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(150, 23);
            this.label4.TabIndex = 114;
            this.label4.Text = "Remove Land Use";
            // 
            // lblSHList
            // 
            this.lblSHList.AutoSize = true;
            this.lblSHList.BackColor = System.Drawing.SystemColors.Control;
            this.lblSHList.ForeColor = System.Drawing.Color.Red;
            this.lblSHList.Location = new System.Drawing.Point(155, 40);
            this.lblSHList.Name = "lblSHList";
            this.lblSHList.Size = new System.Drawing.Size(17, 19);
            this.lblSHList.TabIndex = 113;
            this.lblSHList.Text = "*";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(438, 357);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(121, 19);
            this.label10.TabIndex = 110;
            this.label10.Text = "Land Use Impact:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(395, 311);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(151, 19);
            this.label11.TabIndex = 109;
            this.label11.Text = "Land Use Description:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(454, 267);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(91, 19);
            this.label12.TabIndex = 108;
            this.label12.Text = "Land Use ID:";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 19;
            this.listBox1.Location = new System.Drawing.Point(31, 63);
            this.listBox1.Margin = new System.Windows.Forms.Padding(4);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(400, 156);
            this.listBox1.TabIndex = 106;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(564, 308);
            this.txtDescription.Margin = new System.Windows.Forms.Padding(4);
            this.txtDescription.MaxLength = 30;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(350, 27);
            this.txtDescription.TabIndex = 105;
            // 
            // txtSHID
            // 
            this.txtSHID.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtSHID.Location = new System.Drawing.Point(553, 60);
            this.txtSHID.Margin = new System.Windows.Forms.Padding(4);
            this.txtSHID.MaxLength = 3;
            this.txtSHID.Name = "txtSHID";
            this.txtSHID.ReadOnly = true;
            this.txtSHID.Size = new System.Drawing.Size(60, 27);
            this.txtSHID.TabIndex = 121;
            // 
            // txtImpact
            // 
            this.txtImpact.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtImpact.Location = new System.Drawing.Point(564, 354);
            this.txtImpact.Margin = new System.Windows.Forms.Padding(4);
            this.txtImpact.MaxLength = 3;
            this.txtImpact.Name = "txtImpact";
            this.txtImpact.ReadOnly = true;
            this.txtImpact.Size = new System.Drawing.Size(99, 27);
            this.txtImpact.TabIndex = 122;
            // 
            // txtAID
            // 
            this.txtAID.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtAID.Location = new System.Drawing.Point(399, 393);
            this.txtAID.Margin = new System.Windows.Forms.Padding(4);
            this.txtAID.MaxLength = 3;
            this.txtAID.Name = "txtAID";
            this.txtAID.ReadOnly = true;
            this.txtAID.Size = new System.Drawing.Size(60, 27);
            this.txtAID.TabIndex = 123;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(438, 168);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(81, 19);
            this.label16.TabIndex = 131;
            this.label16.Text = "Site Status:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(438, 133);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(79, 19);
            this.label15.TabIndex = 130;
            this.label15.Text = "Site Name:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(438, 98);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(131, 19);
            this.label14.TabIndex = 129;
            this.label14.Text = "Site Habitat Name:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(438, 63);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(107, 19);
            this.label13.TabIndex = 128;
            this.label13.Text = "Site Habitat ID:";
            // 
            // txtSHName
            // 
            this.txtSHName.Location = new System.Drawing.Point(576, 95);
            this.txtSHName.Margin = new System.Windows.Forms.Padding(4);
            this.txtSHName.MaxLength = 30;
            this.txtSHName.Name = "txtSHName";
            this.txtSHName.Size = new System.Drawing.Size(238, 27);
            this.txtSHName.TabIndex = 127;
            // 
            // txtSSatus
            // 
            this.txtSSatus.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtSSatus.Location = new System.Drawing.Point(527, 165);
            this.txtSSatus.Margin = new System.Windows.Forms.Padding(4);
            this.txtSSatus.MaxLength = 3;
            this.txtSSatus.Name = "txtSSatus";
            this.txtSSatus.ReadOnly = true;
            this.txtSSatus.Size = new System.Drawing.Size(170, 27);
            this.txtSSatus.TabIndex = 126;
            // 
            // txtSName
            // 
            this.txtSName.Location = new System.Drawing.Point(527, 130);
            this.txtSName.Margin = new System.Windows.Forms.Padding(4);
            this.txtSName.MaxLength = 30;
            this.txtSName.Name = "txtSName";
            this.txtSName.Size = new System.Drawing.Size(350, 27);
            this.txtSName.TabIndex = 125;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 40);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 19);
            this.label1.TabIndex = 132;
            this.label1.Text = "Select Site Habitat:";
            // 
            // lblLUList
            // 
            this.lblLUList.AutoSize = true;
            this.lblLUList.BackColor = System.Drawing.SystemColors.Control;
            this.lblLUList.ForeColor = System.Drawing.Color.Red;
            this.lblLUList.Location = new System.Drawing.Point(139, 241);
            this.lblLUList.Name = "lblLUList";
            this.lblLUList.Size = new System.Drawing.Size(17, 19);
            this.lblLUList.TabIndex = 134;
            this.lblLUList.Text = "*";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(27, 241);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(116, 19);
            this.label6.TabIndex = 133;
            this.label6.Text = "Select Land Use:";
            // 
            // txtID
            // 
            this.txtID.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtID.Location = new System.Drawing.Point(564, 264);
            this.txtID.Margin = new System.Windows.Forms.Padding(4);
            this.txtID.MaxLength = 3;
            this.txtID.Name = "txtID";
            this.txtID.ReadOnly = true;
            this.txtID.Size = new System.Drawing.Size(60, 27);
            this.txtID.TabIndex = 135;
            // 
            // txtSID
            // 
            this.txtSID.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtSID.Location = new System.Drawing.Point(847, 192);
            this.txtSID.Margin = new System.Windows.Forms.Padding(4);
            this.txtSID.MaxLength = 3;
            this.txtSID.Name = "txtSID";
            this.txtSID.ReadOnly = true;
            this.txtSID.Size = new System.Drawing.Size(30, 27);
            this.txtSID.TabIndex = 137;
            // 
            // listBox5
            // 
            this.listBox5.FormattingEnabled = true;
            this.listBox5.ItemHeight = 19;
            this.listBox5.Location = new System.Drawing.Point(780, 192);
            this.listBox5.Name = "listBox5";
            this.listBox5.Size = new System.Drawing.Size(60, 23);
            this.listBox5.TabIndex = 136;
            // 
            // Remove_Land_Use
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(944, 441);
            this.Controls.Add(this.txtSID);
            this.Controls.Add(this.listBox5);
            this.Controls.Add(this.txtID);
            this.Controls.Add(this.lblLUList);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtSHName);
            this.Controls.Add(this.txtSSatus);
            this.Controls.Add(this.txtSName);
            this.Controls.Add(this.txtAID);
            this.Controls.Add(this.txtImpact);
            this.Controls.Add(this.txtSHID);
            this.Controls.Add(this.listBox3);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.lblReq);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblSHList);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.txtDescription);
            this.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Remove_Land_Use";
            this.Text = "Remove_Land_Use";
            this.Load += new System.EventHandler(this.Remove_Land_Use_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Label lblReq;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblSHList;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.TextBox txtSHID;
        private System.Windows.Forms.TextBox txtImpact;
        private System.Windows.Forms.TextBox txtAID;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtSHName;
        private System.Windows.Forms.TextBox txtSSatus;
        private System.Windows.Forms.TextBox txtSName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblLUList;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.TextBox txtSID;
        private System.Windows.Forms.ListBox listBox5;
    }
}