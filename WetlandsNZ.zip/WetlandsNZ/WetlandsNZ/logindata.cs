﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WetlandsNZ
{
    public class logindata
    {
        public int LoginID { get; set; }
        public string UserName { get; set; }
        public string PassWord { get; set; }

        public string LoginDetails
        {
            get
            {
                return $"";
            }
        }

    }
}
