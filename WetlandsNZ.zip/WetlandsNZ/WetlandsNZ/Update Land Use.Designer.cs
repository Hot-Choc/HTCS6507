﻿
namespace WetlandsNZ
{
    partial class Update_Land_Use
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtID = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.txtdescrpt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lblReq = new System.Windows.Forms.Label();
            this.btnreturn = new System.Windows.Forms.Button();
            this.update = new System.Windows.Forms.Button();
            this.cbxtype = new System.Windows.Forms.ComboBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.txthold = new System.Windows.Forms.TextBox();
            this.lblLUList = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.ForeColor = System.Drawing.Color.Red;
            this.lbl2.Location = new System.Drawing.Point(522, 165);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(17, 19);
            this.lbl2.TabIndex = 66;
            this.lbl2.Text = "*";
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.ForeColor = System.Drawing.Color.Red;
            this.lbl1.Location = new System.Drawing.Point(522, 119);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(17, 19);
            this.lbl1.TabIndex = 65;
            this.lbl1.Text = "*";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(420, 165);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 19);
            this.label2.TabIndex = 64;
            this.label2.Text = "Land Use Type:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(377, 119);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(151, 19);
            this.label1.TabIndex = 63;
            this.label1.Text = "Land Use Description:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(436, 75);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(91, 19);
            this.label6.TabIndex = 62;
            this.label6.Text = "Land Use ID:";
            // 
            // txtID
            // 
            this.txtID.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtID.Location = new System.Drawing.Point(546, 72);
            this.txtID.Margin = new System.Windows.Forms.Padding(4);
            this.txtID.MaxLength = 3;
            this.txtID.Name = "txtID";
            this.txtID.ReadOnly = true;
            this.txtID.Size = new System.Drawing.Size(60, 27);
            this.txtID.TabIndex = 61;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 19;
            this.listBox1.Location = new System.Drawing.Point(13, 72);
            this.listBox1.Margin = new System.Windows.Forms.Padding(4);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(360, 156);
            this.listBox1.TabIndex = 60;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // txtdescrpt
            // 
            this.txtdescrpt.Location = new System.Drawing.Point(546, 116);
            this.txtdescrpt.Margin = new System.Windows.Forms.Padding(4);
            this.txtdescrpt.MaxLength = 30;
            this.txtdescrpt.Name = "txtdescrpt";
            this.txtdescrpt.Size = new System.Drawing.Size(350, 27);
            this.txtdescrpt.TabIndex = 58;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(384, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(143, 23);
            this.label7.TabIndex = 68;
            this.label7.Text = "Update Land Use";
            // 
            // lblReq
            // 
            this.lblReq.AutoSize = true;
            this.lblReq.ForeColor = System.Drawing.Color.Red;
            this.lblReq.Location = new System.Drawing.Point(526, 222);
            this.lblReq.Name = "lblReq";
            this.lblReq.Size = new System.Drawing.Size(121, 19);
            this.lblReq.TabIndex = 71;
            this.lblReq.Text = "* Required Fields";
            // 
            // btnreturn
            // 
            this.btnreturn.Location = new System.Drawing.Point(811, 214);
            this.btnreturn.Margin = new System.Windows.Forms.Padding(4);
            this.btnreturn.Name = "btnreturn";
            this.btnreturn.Size = new System.Drawing.Size(100, 34);
            this.btnreturn.TabIndex = 70;
            this.btnreturn.Text = "Return";
            this.btnreturn.UseVisualStyleBackColor = true;
            this.btnreturn.Click += new System.EventHandler(this.btnreturn_Click);
            // 
            // update
            // 
            this.update.Location = new System.Drawing.Point(654, 214);
            this.update.Margin = new System.Windows.Forms.Padding(4);
            this.update.Name = "update";
            this.update.Size = new System.Drawing.Size(133, 34);
            this.update.TabIndex = 69;
            this.update.Text = "Update Land Use";
            this.update.UseVisualStyleBackColor = true;
            this.update.Click += new System.EventHandler(this.update_Click);
            // 
            // cbxtype
            // 
            this.cbxtype.FormattingEnabled = true;
            this.cbxtype.Items.AddRange(new object[] {
            "Hunting",
            "Fishing",
            "Agriculture",
            "Waste disposal",
            "Aquaculture",
            "Tourism",
            "Industrial"});
            this.cbxtype.Location = new System.Drawing.Point(546, 162);
            this.cbxtype.Margin = new System.Windows.Forms.Padding(4);
            this.cbxtype.Name = "cbxtype";
            this.cbxtype.Size = new System.Drawing.Size(120, 27);
            this.cbxtype.TabIndex = 72;
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 19;
            this.listBox2.Location = new System.Drawing.Point(57, 236);
            this.listBox2.Margin = new System.Windows.Forms.Padding(4);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(62, 23);
            this.listBox2.TabIndex = 73;
            // 
            // txthold
            // 
            this.txthold.Location = new System.Drawing.Point(127, 232);
            this.txthold.Margin = new System.Windows.Forms.Padding(4);
            this.txthold.MaxLength = 30;
            this.txthold.Name = "txthold";
            this.txthold.Size = new System.Drawing.Size(26, 27);
            this.txthold.TabIndex = 74;
            // 
            // lblLUList
            // 
            this.lblLUList.AutoSize = true;
            this.lblLUList.BackColor = System.Drawing.SystemColors.Control;
            this.lblLUList.ForeColor = System.Drawing.Color.Red;
            this.lblLUList.Location = new System.Drawing.Point(125, 49);
            this.lblLUList.Name = "lblLUList";
            this.lblLUList.Size = new System.Drawing.Size(17, 19);
            this.lblLUList.TabIndex = 136;
            this.lblLUList.Text = "*";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 49);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(116, 19);
            this.label4.TabIndex = 135;
            this.label4.Text = "Select Land Use:";
            // 
            // Update_Land_Use
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(924, 261);
            this.Controls.Add(this.lblLUList);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txthold);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.cbxtype);
            this.Controls.Add(this.lblReq);
            this.Controls.Add(this.btnreturn);
            this.Controls.Add(this.update);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtID);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.txtdescrpt);
            this.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Update_Land_Use";
            this.Text = "Update_Land_Use";
            this.Load += new System.EventHandler(this.Update_Land_Use_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox txtdescrpt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblReq;
        private System.Windows.Forms.Button btnreturn;
        private System.Windows.Forms.Button update;
        private System.Windows.Forms.ComboBox cbxtype;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.TextBox txthold;
        private System.Windows.Forms.Label lblLUList;
        private System.Windows.Forms.Label label4;
    }
}