﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WetlandsNZ
{
    public class site
    {
        public int SiteID { get; set; }
        public string SiteName { get; set; }
        public string Area { get; set; }
        public string Altitude { get; set; }
        public string SiteType { get; set; }
        public string Status { get; set; }

        public string SiteDetails
        {
            get
            {
                return $"ID:  { SiteID },   { SiteName }";
            }
        }
    }
}
