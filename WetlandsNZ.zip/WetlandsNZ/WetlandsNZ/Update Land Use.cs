﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WetlandsNZ
{
    public partial class Update_Land_Use : Form
    {
        List<landuse> Landuse = new List<landuse>();
        List<assignedlanduse> Assignedlanduse = new List<assignedlanduse>();

        public object Text2 { get; private set; }

        public Update_Land_Use()
        {
            InitializeComponent();

            LoadLandUseList();

            LoadAssignedLandUseList();
        }

        private static string LoadConnectionString(string id = "Defult")
        {
            return ConfigurationManager.ConnectionStrings[id].ConnectionString;
        }

        private void LoadLandUseList()
        {
            Landuse = sqliteDataAccess.LoadLandUse();

            WireUpLandUseList();
        }

        private void WireUpLandUseList()
        {
            listBox1.DataSource = null;
            listBox1.DataSource = Landuse;
            listBox1.DisplayMember = "LandUseDetails";
        }

        private void LoadAssignedLandUseList()
        {
            Assignedlanduse = sqliteDataAccess.LoadAssignedLandUse();

            WireUpAssignedLandUseList();
        }

        private void WireUpAssignedLandUseList()
        {
            listBox2.DataSource = null;
            listBox2.DataSource = Assignedlanduse;
            listBox2.DisplayMember = "AssignedLandUseDetails";
        }

        private void update_Click(object sender, EventArgs e)
        {

            if (txtID.Text == "" || txtdescrpt.Text == "" || cbxtype.Text == "")
            {
                MessageBox.Show("Remove Land Use detail/s are missing", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
                lblReq.Visible = true;
                lblLUList.Visible = true;
                lbl1.Visible = true;
                lbl2.Visible = true;

            }

            else
            {
                DialogResult DR = MessageBox.Show("Do you wish to UPDATE this LAND USE ?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);

                if(DR == DialogResult.Yes)
                {
                    landuse l = new landuse();

                    int ID = Int32.Parse(txtID.Text);

                    l.LandUseID = ID;
                    l.LandUseDescription = txtdescrpt.Text;
                    l.LandUseType = cbxtype.Text;

                    string TH = txthold.Text;
                    string TD = txtdescrpt.Text;


                    using (SQLiteConnection cnn = new SQLiteConnection(LoadConnectionString()))
                    {

                        string sqlStatment = "UPDATE [Assigned Land Use] SET Description = REPLACE (Description," + "'" + txthold.Text + "','" + txtdescrpt.Text + "'" + ")";
                        try
                        {
                            cnn.Open();
                            SQLiteCommand cmd = new SQLiteCommand(sqlStatment, cnn);
                            cmd.CommandType = CommandType.Text;
                            cmd.ExecuteNonQuery();

                        }
                        finally
                        {
                            cnn.Close();
                        }
                    }

                    sqliteDataAccess.UpdateLandUse(l);

                    MessageBox.Show("Land Use Updated Successfully");

                    LoadLandUseList();

                    LoadAssignedLandUseList();

                    lblReq.Visible = false;
                    lblLUList.Visible = false;
                    lbl1.Visible = false;
                    lbl2.Visible = false;

                    listBox1.SelectedItem = "";

                    txtID.Text = "";
                    txtdescrpt.Text = "";
                    cbxtype.Text = "";
                }

                else
                {
                    lblReq.Visible = false;
                    lblLUList.Visible = false;
                    lbl1.Visible = false;
                    lbl2.Visible = false;

                    listBox1.SelectedItem = "";

                    txtID.Text = "";
                    txtdescrpt.Text = "";
                    cbxtype.Text = "";
                }

                
            }         
        }


        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            landuse selectedlanduse = (landuse)listBox1.SelectedItem;
            txtID.Text = selectedlanduse.LandUseID.ToString();
            txtdescrpt.Text = selectedlanduse.LandUseDescription;
            cbxtype.Text = selectedlanduse.LandUseType ;
            txthold.Text = selectedlanduse.LandUseDescription;

        }
        private void btnreturn_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void Update_Land_Use_Load(object sender, EventArgs e)
        {
            lblReq.Visible = false;
            lblLUList.Visible = false;
            lbl1.Visible = false;
            lbl2.Visible = false;

            listBox2.Visible = false;
            txthold.Visible = false;

            txtID.Text = "";
            txtdescrpt.Text = "";
            cbxtype.Text = "";
        }
    }
}
