﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WetlandsNZ
{
    public class sqliteDataAccess
    {
        public static List<site> loadSites()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var output = cnn.Query<site>("Select * from Site", new DynamicParameters());
                return output.ToList();
            }
        }

        public static void SaveSite(site Site)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                cnn.Execute("insert into Site (SiteName, Area, Altitude, SiteType, Status) values (@SiteName, @Area, @Altitude, @SiteType, @Status)", Site);
            }
        }

        public static void UpdateSite(site Site)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                cnn.Execute("insert into Site (SiteID, SiteName, Area, Altitude, SiteType, Status) values (@SiteID, @SiteName, @Area, @Altitude, @SiteType, @Status)", Site);
            }
        }

        public static void DeleteSite(site Site)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                cnn.Execute("insert into Site (SiteID, SiteName, Area, Altitude, SiteType, Status) values (@SiteID, @SiteName, @Area, @Altitude, @SiteType, @Status)", Site);
            }

            using (SQLiteConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                string sqlStatment = "DELETE FROM Site WHERE SiteName == '0'";
                try
                {
                    cnn.Open();
                    SQLiteCommand cmd = new SQLiteCommand(sqlStatment, cnn);
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();

                }
                finally
                {
                    cnn.Close();
                }
            }
        }

        private static string LoadConnectionString(string id = "Defult")
        {
            return ConfigurationManager.ConnectionStrings[id].ConnectionString;
        }

        public static List<landuse> LoadLandUse()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var output2 = cnn.Query<landuse>("Select * from [Land Use]", new DynamicParameters());
                return output2.ToList();
            }
        }

        public static void UpdateLandUse(landuse Landuse)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                cnn.Execute("insert into [Land Use] (LandUseID, LandUseDescription, LandUseType) values (@LandUseID, @LandUseDescription, @LandUseType)", Landuse);
            }
        }

        public static List<sitehabitat> LoadSiteHabitat()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var output3 = cnn.Query<sitehabitat>("Select * from [Site Habitat]", new DynamicParameters());
                return output3.ToList();
            }
        }

        public static List<assignedlanduse> LoadAssignedLandUse()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var output4 = cnn.Query<assignedlanduse>("Select * from [Assigned Land Use]", new DynamicParameters());
                return output4.ToList();
            }
        }

        public static void SaveAssignedLandUse(assignedlanduse Assignedlanduse)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                cnn.Execute("insert into [Assigned Land Use] (SiteHabitatID, LandUseID, Impact, Description) values (@SiteHabitatID, @LandUseID, @Impact, @Description)", Assignedlanduse);
            }
        }

        public static void DeleteAssignedLandUse(assignedlanduse AssignedLanduse)
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                cnn.Execute("insert into [Assigned Land Use] (AssignedID, SiteHabitatID, LandUseID, Impact, Description) values (@AssignedID, @SiteHabitatID, @LandUseID, @Impact, @Description)", AssignedLanduse);
            }

            using (SQLiteConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                string sqlStatment = "DELETE FROM [Assigned Land Use] WHERE Impact == '0'";
                try
                {
                    cnn.Open();
                    SQLiteCommand cmd = new SQLiteCommand(sqlStatment, cnn);
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();

                }
                finally
                {
                    cnn.Close();
                }
            }
        }

        public static List<logindata> LoadLogin()
        {
            using (IDbConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                var output5 = cnn.Query<logindata>("Select * from [Login]", new DynamicParameters());
                return output5.ToList();
            }
        }
    }
}
