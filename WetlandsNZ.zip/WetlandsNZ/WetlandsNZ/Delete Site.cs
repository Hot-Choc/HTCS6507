﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WetlandsNZ
{
    public partial class Delete_Site : Form
    {
        List<site> Site = new List<site>();

        public Delete_Site()
        {
            InitializeComponent();

            LoadSiteList();
        }

        private void LoadSiteList()
        {
            Site = sqliteDataAccess.loadSites();

            WireUpSiteList();
        }

        private void WireUpSiteList()
        {
            listBox1.DataSource = null;
            listBox1.DataSource = Site;
            listBox1.DisplayMember = "SiteDetails";
        }
        
        private void btnreturn_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            site selectedsite = (site)listBox1.SelectedItem;
            txtID.Text = selectedsite.SiteID.ToString();
            txtname.Text = selectedsite.SiteName;
            txttype.Text = selectedsite.SiteType;
            txtstatus.Text = selectedsite.Status;
        }

        private void delete_Click(object sender, EventArgs e)
        {
            if(txtID.Text == "")
            {
                MessageBox.Show("Site detail are missing", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
                lblReq.Visible = true;
                lblList.Visible = true;
            }

            else
            {
                DialogResult DR = MessageBox.Show("Do you wish to DELETE this SITE ?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);

                if (DR == DialogResult.Yes)
                {
                    site s = new site();

                    int ID = Int32.Parse(txtID.Text);

                    s.SiteID = ID;
                    s.SiteName = "0";
                    s.Area = "";
                    s.Altitude = "";
                    s.SiteType = "";
                    s.Status = "";

                    sqliteDataAccess.DeleteSite(s);

                    txtID.Text = "";
                    txtname.Text = "";
                    txttype.Text = "";
                    txtstatus.Text = "";

                    MessageBox.Show("Site Deleted Successfully");

                    lblReq.Visible = false;
                    lblList.Visible = false;

                    LoadSiteList();
                }

                else
                {
                    txtID.Text = "";
                    txtname.Text = "";
                    txttype.Text = "";
                    txtstatus.Text = "";

                    lblReq.Visible = false;
                    lblList.Visible = false;

                }
            }  
            
            

        }

        private void Delete_Site_Load(object sender, EventArgs e)
        {
            lblReq.Visible = false;
            lblList.Visible = false;

            txtID.Text = "";
            txtname.Text = "";
            txttype.Text = "";
            txtstatus.Text = "";
        }
    }
}
