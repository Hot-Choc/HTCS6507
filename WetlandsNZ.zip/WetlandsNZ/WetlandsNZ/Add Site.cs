﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WetlandsNZ
{
    public partial class Add_Site : Form
    {
        List<site> Site = new List<site>();

        public Add_Site()
        {
            InitializeComponent();

            LoadSiteList();
        }

        private void LoadSiteList()
        {
            Site = sqliteDataAccess.loadSites();
        }

        private void Add_Site_Load(object sender, EventArgs e)
        {

            lblReq.Visible = false;
            lbl1.Visible = false;
            lbl2.Visible = false;
            lbl3.Visible = false;
            lbl4.Visible = false;
            lbl5.Visible = false;
        }

        private void add_Click(object sender, EventArgs e)
        {
            if(txtname.Text == "" || txtarea.Text == "" || txtaltitude.Text == "" || cbxtype.Text == "" || cbxstatus.Text == "")
            {
                MessageBox.Show("Site detail/s are missing", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
                lblReq.Visible = true;
                lbl1.Visible = true;
                lbl2.Visible = true;
                lbl3.Visible = true;
                lbl4.Visible = true;
                lbl5.Visible = true;

            }

            else
            {
                site s = new site();

                s.SiteName = txtname.Text;
                s.Area = txtarea.Text;
                s.Altitude = txtaltitude.Text;
                s.SiteType = cbxtype.Text;
                s.Status = cbxstatus.Text;

                sqliteDataAccess.SaveSite(s);

                MessageBox.Show("Site Added Successfully");

                txtname.Text = "";
                txtarea.Text = "";
                txtaltitude.Text = "";
                cbxtype.SelectedItem = null;
                cbxstatus.SelectedItem = null;

                LoadSiteList();

                lblReq.Visible = false;
                lbl1.Visible = false;
                lbl2.Visible = false;
                lbl3.Visible = false;
                lbl4.Visible = false;
                lbl5.Visible = false;

            }
            
        }

        private void btnreturn_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
