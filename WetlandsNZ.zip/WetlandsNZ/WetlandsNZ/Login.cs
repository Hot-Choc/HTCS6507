﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WetlandsNZ
{
    public partial class Login : Form
    {
        private Main_Menu mainMenuFrm;

        List<logindata> Login0 = new List<logindata>();

        public Login()
        {
            InitializeComponent();

            LoadLoginList();
        }

        private void LoadLoginList()
        {
            Login0 = sqliteDataAccess.LoadLogin();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtUN.Text == "" || txtPW.Text == "")
            {
                MessageBox.Show("Username and/or Password are missing", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);

                lblReq.Visible = true;
                lblUNR.Visible = true;
                lblPWR.Visible = true;
            }

            else
            {
                string filter = txtUN.Text;
                listBox1.Items.Clear();
                foreach (logindata UName in Login0.Where(A => A.UserName == (filter)))
                {
                    listBox1.Items.Add(UName.UserName + "  " + UName.PassWord);

                    txtCheck.Text = UName.PassWord;

                    if (txtPW.Text == txtCheck.Text)
                    {
                        this.Hide();

                        if (mainMenuFrm == null)
                        {
                            mainMenuFrm = new Main_Menu();
                        }
                        mainMenuFrm.ShowDialog();

                        lblReq.Visible = false;
                        lblUNR.Visible = false;
                        lblPWR.Visible = false;
                    }

                    else
                    {
                        MessageBox.Show("Username and/or Password invalid ", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
            }
                
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            listBox1.Visible = false;
            txtCheck.Visible = false;
            
            lblReq.Visible = false;
            lblUNR.Visible = false;
            lblPWR.Visible = false;
        }
    }
}
