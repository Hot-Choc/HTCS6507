﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WetlandsNZ
{
    public partial class Land_Uses_Report : Form
    {
        List<sitehabitat> SiteHabitat = new List<sitehabitat>();
        List<landuse> Landuse = new List<landuse>();
        List<assignedlanduse> Assignedlanduse = new List<assignedlanduse>();

        public Land_Uses_Report()
        {
            InitializeComponent();

            LoadSiteHabitatList();

            LoadLandUseList();

            LoadAssignedLandUseList();
        }

        private void LoadLandUseList()
        {
            Landuse = sqliteDataAccess.LoadLandUse();
        }

        private void LoadSiteHabitatList()
        {
            SiteHabitat = sqliteDataAccess.LoadSiteHabitat();
        }

        private void LoadAssignedLandUseList()
        {
            Assignedlanduse = sqliteDataAccess.LoadAssignedLandUse();
        }

        private void btnDisReport_Click(object sender, EventArgs e)
        {
            string title = "WetlandsNZ Land Uses Report" + Environment.NewLine + Environment.NewLine;
            rtxtReport.SelectionFont = new Font(this.rtxtReport.Font.FontFamily, 20, FontStyle.Bold);
            rtxtReport.SelectionAlignment = HorizontalAlignment.Center;
            rtxtReport.AppendText(title);


            foreach (landuse row in Landuse)
            {
                rtxtReport.SelectionAlignment = HorizontalAlignment.Left;
                rtxtReport.SelectionFont = new Font(this.rtxtReport.Font, FontStyle.Bold);
                rtxtReport.AppendText("\tLand Use ID:   " + row.LandUseID + Environment.NewLine);
                rtxtReport.SelectionFont = new Font(this.rtxtReport.Font, FontStyle.Regular);
                rtxtReport.AppendText("\tName:   " + row.LandUseDescription + Environment.NewLine + "\tType:   " + row.LandUseType + Environment.NewLine + Environment.NewLine);

                foreach (assignedlanduse row2 in Assignedlanduse)
                {
                    if (row2.LandUseID.ToString() == row.LandUseID.ToString())
                    {
                        
                        rtxtReport.SelectionFont = new Font(this.rtxtReport.Font, FontStyle.Bold);

                        foreach (sitehabitat row3 in SiteHabitat)
                        {
                            if (row3.SiteHabitatID.ToString() == row2.SiteHabitatID.ToString())
                            {
                                rtxtReport.SelectionAlignment = HorizontalAlignment.Left;
                                rtxtReport.SelectionFont = new Font(this.rtxtReport.Font, FontStyle.Bold);
                                rtxtReport.AppendText("\t\tSite Habitat ID:   " + row3.SiteHabitatID);
                                rtxtReport.SelectionFont = new Font(this.rtxtReport.Font, FontStyle.Regular);
                                rtxtReport.AppendText("\t\tHabitatID:   " + row3.HabitatID.ToString());
                                rtxtReport.AppendText(Environment.NewLine);
                                rtxtReport.AppendText("\t\tName:   " + row3.SiteHabitatName);
                                rtxtReport.AppendText("\t\tArea:   " + row3.Area.ToString());
                                rtxtReport.AppendText("\t\tImpact:   " + row2.Impact + Environment.NewLine);
                                rtxtReport.AppendText(Environment.NewLine);

                                rtxtReport.SelectionFont = new Font(this.rtxtReport.Font, FontStyle.Bold);
                            }
                        }
                    }
                }

                rtxtReport.AppendText(Environment.NewLine);
            }
        }

        private void btnreturn_Click(object sender, EventArgs e)
        {
            this.Hide();
            rtxtReport.Text = "";
        }
    }
}
