﻿
namespace WetlandsNZ
{
    partial class Main_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AddSitefrmbtn = new System.Windows.Forms.Button();
            this.UpdateSitefrmbtn = new System.Windows.Forms.Button();
            this.DeleteSitefrmbtn = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.Exitbtn = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // AddSitefrmbtn
            // 
            this.AddSitefrmbtn.Location = new System.Drawing.Point(13, 57);
            this.AddSitefrmbtn.Margin = new System.Windows.Forms.Padding(4);
            this.AddSitefrmbtn.Name = "AddSitefrmbtn";
            this.AddSitefrmbtn.Size = new System.Drawing.Size(180, 40);
            this.AddSitefrmbtn.TabIndex = 0;
            this.AddSitefrmbtn.Text = "Add Site Form";
            this.AddSitefrmbtn.UseVisualStyleBackColor = true;
            this.AddSitefrmbtn.Click += new System.EventHandler(this.AddSitefrmbtn_Click);
            // 
            // UpdateSitefrmbtn
            // 
            this.UpdateSitefrmbtn.Location = new System.Drawing.Point(13, 130);
            this.UpdateSitefrmbtn.Margin = new System.Windows.Forms.Padding(4);
            this.UpdateSitefrmbtn.Name = "UpdateSitefrmbtn";
            this.UpdateSitefrmbtn.Size = new System.Drawing.Size(180, 40);
            this.UpdateSitefrmbtn.TabIndex = 1;
            this.UpdateSitefrmbtn.Text = "Update Site Form";
            this.UpdateSitefrmbtn.UseVisualStyleBackColor = true;
            this.UpdateSitefrmbtn.Click += new System.EventHandler(this.UpdateSitefrmbtn_Click);
            // 
            // DeleteSitefrmbtn
            // 
            this.DeleteSitefrmbtn.Location = new System.Drawing.Point(13, 216);
            this.DeleteSitefrmbtn.Margin = new System.Windows.Forms.Padding(4);
            this.DeleteSitefrmbtn.Name = "DeleteSitefrmbtn";
            this.DeleteSitefrmbtn.Size = new System.Drawing.Size(180, 40);
            this.DeleteSitefrmbtn.TabIndex = 2;
            this.DeleteSitefrmbtn.Text = "Delete Site Form";
            this.DeleteSitefrmbtn.UseVisualStyleBackColor = true;
            this.DeleteSitefrmbtn.Click += new System.EventHandler(this.DeleteSitefrmbtn_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(53, 300);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(140, 60);
            this.button4.TabIndex = 3;
            this.button4.Text = "Produce Sites Report Form";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(241, 57);
            this.button5.Margin = new System.Windows.Forms.Padding(4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(180, 40);
            this.button5.TabIndex = 4;
            this.button5.Text = "Assign Land Use Form";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(241, 130);
            this.button6.Margin = new System.Windows.Forms.Padding(4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(180, 40);
            this.button6.TabIndex = 5;
            this.button6.Text = "Remove Land Use Form";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(241, 216);
            this.button7.Margin = new System.Windows.Forms.Padding(4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(180, 40);
            this.button7.TabIndex = 6;
            this.button7.Text = "Update Land Use Form";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(241, 300);
            this.button8.Margin = new System.Windows.Forms.Padding(4);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(140, 60);
            this.button8.TabIndex = 7;
            this.button8.Text = "Produce Land Uses Report Form";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // Exitbtn
            // 
            this.Exitbtn.Location = new System.Drawing.Point(150, 404);
            this.Exitbtn.Margin = new System.Windows.Forms.Padding(4);
            this.Exitbtn.Name = "Exitbtn";
            this.Exitbtn.Size = new System.Drawing.Size(140, 40);
            this.Exitbtn.TabIndex = 8;
            this.Exitbtn.Text = "Exit";
            this.Exitbtn.UseVisualStyleBackColor = true;
            this.Exitbtn.Click += new System.EventHandler(this.Exitbtn_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(166, 20);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(102, 23);
            this.label7.TabIndex = 45;
            this.label7.Text = "Main Menu";
            // 
            // Main_Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 461);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Exitbtn);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.DeleteSitefrmbtn);
            this.Controls.Add(this.UpdateSitefrmbtn);
            this.Controls.Add(this.AddSitefrmbtn);
            this.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Main_Menu";
            this.Text = "Main_Menu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button AddSitefrmbtn;
        private System.Windows.Forms.Button UpdateSitefrmbtn;
        private System.Windows.Forms.Button DeleteSitefrmbtn;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button Exitbtn;
        private System.Windows.Forms.Label label7;
    }
}