﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WetlandsNZ
{
    public partial class Main_Menu : Form
    {
        private Add_Site AddSiteFrm;
        private Update_Site UpdateSiteFrm;
        private Delete_Site DeleteSiteFrm;
        private Update_Land_Use UpdateLandFrm;
        private Assign_Land_Use AssignLandUseFrm;
        private Remove_Land_Use RemoveLandUseFrm;
        private Sites_Report SitesReportFrm;
        private Land_Uses_Report LandUsesReportFrm;

        public Main_Menu()
        {
            InitializeComponent();
        }

        private void Exitbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AddSitefrmbtn_Click(object sender, EventArgs e)
        {
            if (AddSiteFrm == null)
            {
                AddSiteFrm = new Add_Site();
            }
            AddSiteFrm.ShowDialog();
        }

        private void UpdateSitefrmbtn_Click(object sender, EventArgs e)
        {
            if (UpdateSiteFrm == null)
            {
                UpdateSiteFrm = new Update_Site();
            }
            UpdateSiteFrm.ShowDialog();
        }

        private void DeleteSitefrmbtn_Click(object sender, EventArgs e)
        {
            if (DeleteSiteFrm == null)
            {
                DeleteSiteFrm = new Delete_Site();
            }
            DeleteSiteFrm.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (UpdateLandFrm == null)
            {
                UpdateLandFrm = new Update_Land_Use();
            }
            UpdateLandFrm.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (AssignLandUseFrm == null)
            {
                AssignLandUseFrm = new Assign_Land_Use();
            }
            AssignLandUseFrm.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (RemoveLandUseFrm == null)
            {
                RemoveLandUseFrm = new Remove_Land_Use();
            }
            RemoveLandUseFrm.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (SitesReportFrm == null)
            {
                SitesReportFrm = new Sites_Report();
            }
            SitesReportFrm.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (LandUsesReportFrm == null)
            {
                LandUsesReportFrm = new Land_Uses_Report();
            }
            LandUsesReportFrm.ShowDialog();
        }
    }
}

