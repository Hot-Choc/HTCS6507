﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WetlandsNZ
{
    public partial class Sites_Report : Form
    {
        List<site> Site = new List<site>();
        List<sitehabitat> SiteHabitat = new List<sitehabitat>();

        public Sites_Report()
        {
            InitializeComponent();

            LoadSiteList();

            LoadSiteHabitatList();
        }

        private void LoadSiteList()
        {
            Site = sqliteDataAccess.loadSites();
        }

        private void LoadSiteHabitatList()
        {
            SiteHabitat = sqliteDataAccess.LoadSiteHabitat();
        }

        private void Sites_Report_Load(object sender, EventArgs e)
        {

        }

        private void btnDisReport_Click(object sender, EventArgs e)
        {
            string title = "WetlandsNZ Sites Report" + Environment.NewLine + Environment.NewLine;
            rtxtReport.SelectionFont = new Font(this.rtxtReport.Font.FontFamily, 20, FontStyle.Bold);
            rtxtReport.SelectionAlignment = HorizontalAlignment.Center;
            rtxtReport.AppendText(title);


            foreach (site row in Site)
            {
                rtxtReport.SelectionAlignment = HorizontalAlignment.Left;
                rtxtReport.SelectionFont = new Font(this.rtxtReport.Font, FontStyle.Bold);
                rtxtReport.AppendText("\tSite ID:   " + row.SiteID + Environment.NewLine);
                rtxtReport.AppendText(Environment.NewLine);
                rtxtReport.SelectionFont = new Font(this.rtxtReport.Font, FontStyle.Regular);
                rtxtReport.AppendText("\tName:   " + row.SiteName + Environment.NewLine + "\tType:   " + row.SiteType + Environment.NewLine + "\tStatus:   " + row.Status + Environment.NewLine + Environment.NewLine);
                

                foreach (sitehabitat row2 in SiteHabitat)
                {
                    if (row2.SiteID.ToString() == row.SiteID.ToString())
                    {
                        rtxtReport.SelectionAlignment = HorizontalAlignment.Left;
                        rtxtReport.SelectionFont = new Font(this.rtxtReport.Font, FontStyle.Bold);
                        rtxtReport.AppendText("\t\t\tSite Habitat ID:   " + row2.SiteHabitatID);
                        rtxtReport.SelectionFont = new Font(this.rtxtReport.Font, FontStyle.Regular);
                        rtxtReport.AppendText("\t\t\tHabitatID:   " + row2.HabitatID.ToString());
                        rtxtReport.AppendText(Environment.NewLine);
                        rtxtReport.AppendText("\t\t\tName:   " + row2.SiteHabitatName);
                        rtxtReport.AppendText("\t\tArea:   " + row2.Area.ToString() + Environment.NewLine);
                        rtxtReport.AppendText(Environment.NewLine);

                        rtxtReport.SelectionFont = new Font(this.rtxtReport.Font, FontStyle.Bold);
                        
                    }
                }

                rtxtReport.AppendText(Environment.NewLine);
            }
        }

        private void btnreturn_Click(object sender, EventArgs e)
        {
            this.Hide();
            rtxtReport.Text = "";
        }
    }
}
