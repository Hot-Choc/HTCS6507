﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WetlandsNZ
{
    public class sitehabitat
    {
        public int SiteHabitatID { get; set; }
        public string SiteHabitatName { get; set; }
        public string Area { get; set; }
        public int HabitatID { get; set; }
        public int SiteID { get; set; }


        public string SiteHabitatDetails
        {
            get
            {
                return $"ID:  { SiteHabitatID },  { SiteHabitatName }";
            }
        }
    }
}
