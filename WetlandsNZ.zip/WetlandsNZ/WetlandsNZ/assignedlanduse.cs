﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WetlandsNZ
{
    public class assignedlanduse
    {
        public int AssignedID { get; set; }
        public int LandUseID { get; set; }
        public int SiteHabitatID { get; set; }
        public string Impact { get; set; }
        public string Description { get; set; }


        public string AssignedLandUseDetails
        {
            get
            {
                return $" Land Use:  { LandUseID }, { Description }, Impact: { Impact } ";
            }
        }


    }
}
