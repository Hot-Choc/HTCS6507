﻿
namespace WetlandsNZ
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLogin = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.txtUN = new System.Windows.Forms.TextBox();
            this.txtPW = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.txtCheck = new System.Windows.Forms.TextBox();
            this.lblUN = new System.Windows.Forms.Label();
            this.lblUNR = new System.Windows.Forms.Label();
            this.lblPW = new System.Windows.Forms.Label();
            this.lblPWR = new System.Windows.Forms.Label();
            this.lblReq = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnLogin
            // 
            this.btnLogin.Location = new System.Drawing.Point(140, 149);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(96, 38);
            this.btnLogin.TabIndex = 0;
            this.btnLogin.Text = "Login";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(242, 149);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(96, 38);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // txtUN
            // 
            this.txtUN.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUN.Location = new System.Drawing.Point(111, 45);
            this.txtUN.MaxLength = 30;
            this.txtUN.Name = "txtUN";
            this.txtUN.Size = new System.Drawing.Size(227, 27);
            this.txtUN.TabIndex = 2;
            // 
            // txtPW
            // 
            this.txtPW.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPW.Location = new System.Drawing.Point(111, 78);
            this.txtPW.MaxLength = 30;
            this.txtPW.Name = "txtPW";
            this.txtPW.Size = new System.Drawing.Size(227, 27);
            this.txtPW.TabIndex = 3;
            this.txtPW.UseSystemPasswordChar = true;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 19;
            this.listBox1.Location = new System.Drawing.Point(170, 120);
            this.listBox1.Name = "listBox1";
            this.listBox1.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.listBox1.Size = new System.Drawing.Size(66, 23);
            this.listBox1.TabIndex = 4;
            // 
            // txtCheck
            // 
            this.txtCheck.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCheck.Location = new System.Drawing.Point(270, 116);
            this.txtCheck.Name = "txtCheck";
            this.txtCheck.Size = new System.Drawing.Size(25, 27);
            this.txtCheck.TabIndex = 5;
            // 
            // lblUN
            // 
            this.lblUN.AutoSize = true;
            this.lblUN.Location = new System.Drawing.Point(13, 48);
            this.lblUN.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUN.Name = "lblUN";
            this.lblUN.Size = new System.Drawing.Size(79, 19);
            this.lblUN.TabIndex = 113;
            this.lblUN.Text = "Username:";
            // 
            // lblUNR
            // 
            this.lblUNR.AutoSize = true;
            this.lblUNR.BackColor = System.Drawing.SystemColors.Control;
            this.lblUNR.ForeColor = System.Drawing.Color.Red;
            this.lblUNR.Location = new System.Drawing.Point(87, 48);
            this.lblUNR.Name = "lblUNR";
            this.lblUNR.Size = new System.Drawing.Size(17, 19);
            this.lblUNR.TabIndex = 112;
            this.lblUNR.Text = "*";
            // 
            // lblPW
            // 
            this.lblPW.AutoSize = true;
            this.lblPW.Location = new System.Drawing.Point(13, 81);
            this.lblPW.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPW.Name = "lblPW";
            this.lblPW.Size = new System.Drawing.Size(75, 19);
            this.lblPW.TabIndex = 115;
            this.lblPW.Text = "Password:";
            // 
            // lblPWR
            // 
            this.lblPWR.AutoSize = true;
            this.lblPWR.BackColor = System.Drawing.SystemColors.Control;
            this.lblPWR.ForeColor = System.Drawing.Color.Red;
            this.lblPWR.Location = new System.Drawing.Point(84, 81);
            this.lblPWR.Name = "lblPWR";
            this.lblPWR.Size = new System.Drawing.Size(17, 19);
            this.lblPWR.TabIndex = 114;
            this.lblPWR.Text = "*";
            // 
            // lblReq
            // 
            this.lblReq.AutoSize = true;
            this.lblReq.ForeColor = System.Drawing.Color.Red;
            this.lblReq.Location = new System.Drawing.Point(13, 159);
            this.lblReq.Name = "lblReq";
            this.lblReq.Size = new System.Drawing.Size(121, 19);
            this.lblReq.TabIndex = 116;
            this.lblReq.Text = "* Required Fields";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(166, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 23);
            this.label4.TabIndex = 117;
            this.label4.Text = "Login";
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(361, 212);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblReq);
            this.Controls.Add(this.lblPW);
            this.Controls.Add(this.lblPWR);
            this.Controls.Add(this.lblUN);
            this.Controls.Add(this.lblUNR);
            this.Controls.Add(this.txtCheck);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.txtPW);
            this.Controls.Add(this.txtUN);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnLogin);
            this.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Login";
            this.Text = "Login";
            this.Load += new System.EventHandler(this.Login_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TextBox txtUN;
        private System.Windows.Forms.TextBox txtPW;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox txtCheck;
        private System.Windows.Forms.Label lblUN;
        private System.Windows.Forms.Label lblUNR;
        private System.Windows.Forms.Label lblPW;
        private System.Windows.Forms.Label lblPWR;
        private System.Windows.Forms.Label lblReq;
        private System.Windows.Forms.Label label4;
    }
}