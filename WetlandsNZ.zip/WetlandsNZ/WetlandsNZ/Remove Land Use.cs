﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WetlandsNZ
{
    public partial class Remove_Land_Use : Form
    {
        List<sitehabitat> SiteHabitat = new List<sitehabitat>();
        List<assignedlanduse> AssignedLandUse = new List<assignedlanduse>();
        List<landuse> Landuse = new List<landuse>();
        List<site> Site = new List<site>();

        public Remove_Land_Use()
        {
            InitializeComponent();

            SiteHabitatList();

            LoadAssigendLandUseList();
            
            LoadSiteList();
        }

        private void LoadSiteList()
        {
            Site = sqliteDataAccess.loadSites();
        }

        private void SiteHabitatList()
        {
            SiteHabitat = sqliteDataAccess.LoadSiteHabitat();

            WireUpSiteHabitatList();
        }

        private void WireUpSiteHabitatList()
        {
            listBox1.DataSource = null;
            listBox1.DataSource = SiteHabitat;
            listBox1.DisplayMember = "SiteHabitatDetails";
        }



        private void LoadAssigendLandUseList()
        {
            AssignedLandUse = sqliteDataAccess.LoadAssignedLandUse();

            WireUpAssignedLandUseList();
        }

        private void WireUpAssignedLandUseList()
        {
            listBox2.DataSource = null;
            listBox2.DataSource = AssignedLandUse;
            listBox2.DisplayMember = "AssignedLandUseDetails";
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            sitehabitat selectedsitehabitat = (sitehabitat)listBox1.SelectedItem;
            txtSHID.Text = selectedsitehabitat.SiteHabitatID.ToString();
            txtSID.Text = selectedsitehabitat.SiteID.ToString();
            txtSHName.Text = selectedsitehabitat.SiteHabitatName;

            listBox3.DataSource = listBox2.Items.Cast<assignedlanduse>().Where(x => x.SiteHabitatID.Equals(selectedsitehabitat.SiteHabitatID)).ToList();
            listBox3.DisplayMember = "AssignedLandUseDetails";

            

            string filter2 = txtSID.Text;
            listBox5.Items.Clear();
            foreach (site sites in Site.Where(A => A.SiteID.ToString() == (filter2)))
            {
                listBox5.Items.Add(sites.SiteID.ToString() + "  " + sites.SiteName + "  " + sites.Status);

                txtSName.Text = sites.SiteName;
                txtSSatus.Text = sites.Status;

            }

        }


        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            assignedlanduse selectedassignedlanduse = (assignedlanduse)listBox3.SelectedItem;

            txtAID.Text = selectedassignedlanduse.AssignedID.ToString();
            txtID.Text = selectedassignedlanduse.LandUseID.ToString();
            txtDescription.Text = selectedassignedlanduse.Description;
            txtImpact.Text = selectedassignedlanduse.Impact;


        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (txtSHID.Text == "" || txtID.Text == "")
            {
                MessageBox.Show("Remove Land Use detail/s are missing", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
                lblReq.Visible = true;
                lblSHList.Visible = true;
                lblLUList.Visible = true;

            }

            else
            {
                assignedlanduse A = new assignedlanduse();

                int ID = Int32.Parse(txtAID.Text);
                int SHID = Int32.Parse(txtSHID.Text);
                int LUID = Int32.Parse(txtID.Text);

                A.AssignedID = ID;
                A.SiteHabitatID = SHID;
                A.LandUseID = LUID;
                A.Impact = "0";
                A.Description = "";

                sqliteDataAccess.DeleteAssignedLandUse(A);

                MessageBox.Show("Land Use Removed Successfully");

                txtSHID.Text = "";
                txtSHName.Text = "";
                txtSName.Text = "";
                txtSSatus.Text = "";

                txtID.Text = "";
                txtDescription.Text = "";
                txtImpact.Text = "";

                lblReq.Visible = false;
                lblSHList.Visible = false;
                lblLUList.Visible = false;

                SiteHabitatList();

                LoadAssigendLandUseList();
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void Remove_Land_Use_Load(object sender, EventArgs e)
        {
            lblReq.Visible = false;
            lblSHList.Visible = false;
            lblLUList.Visible = false;


            listBox2.Visible = false;
            txtAID.Visible = false;
            listBox5.Visible = false;
            txtSID.Visible = false;

            txtSHID.Text = "";
            txtSHName.Text = "";
            txtSName.Text = "";
            txtSSatus.Text = "";

            txtID.Text = "";
            txtDescription.Text = "";
            txtImpact.Text = "";
        }
    }
}
