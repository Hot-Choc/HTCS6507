﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WetlandsNZ
{
    public partial class Assign_Land_Use : Form
    {
        List<sitehabitat> SiteHabitat = new List<sitehabitat>();
        List<assignedlanduse> AssignedLandUse = new List<assignedlanduse>();
        List<landuse> Landuse = new List<landuse>();
        List<site> Site = new List<site>();


        public Assign_Land_Use()
        {
            InitializeComponent();

            LoadSiteHabitatList();

            LoadAssigendLandUseList();

            LoadLandUseList();

            LoadSiteList();

        }

        private static string LoadConnectionString(string id = "Defult")
        {
            return ConfigurationManager.ConnectionStrings[id].ConnectionString;
        }

        private void LoadSiteList()
        {
            Site = sqliteDataAccess.loadSites();
        }

        private void LoadSiteHabitatList()
        {
            SiteHabitat = sqliteDataAccess.LoadSiteHabitat();

            WireUpSiteHabitatList();
        }

        private void WireUpSiteHabitatList()
        {
            listBox1.DataSource = null;
            listBox1.DataSource = SiteHabitat;
            listBox1.DisplayMember = "SiteHabitatDetails";
        }

        private void LoadAssigendLandUseList()
        {
            AssignedLandUse = sqliteDataAccess.LoadAssignedLandUse();

            WireUpAssignedLandUseList();
        }

        private void WireUpAssignedLandUseList()
        {
            listBox2.DataSource = null;
            listBox2.DataSource = AssignedLandUse;
            listBox2.DisplayMember = "AssignedLandUseDetails";
        }

        

        private void LoadLandUseList()
        {
            Landuse = sqliteDataAccess.LoadLandUse();

            WireUpLandUseList();
        }

        private void WireUpLandUseList()
        {
            listBox4.DataSource = null;
            listBox4.DataSource = Landuse;
            listBox4.DisplayMember = "LandUseDetails";
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            sitehabitat selectedsitehabitat = (sitehabitat)listBox1.SelectedItem;
            txtSHID.Text = selectedsitehabitat.SiteHabitatID.ToString();
            txtSID.Text = selectedsitehabitat.SiteID.ToString();
            txtSHName.Text = selectedsitehabitat.SiteHabitatName;

            listBox3.DisplayMember = listBox2.DisplayMember;

            string filter = txtSHID.Text;
            listBox3.Items.Clear();
            foreach (assignedlanduse assigned in AssignedLandUse.Where(A => A.SiteHabitatID.ToString() == (filter)))
            {
                listBox3.Items.Add("Land Use: " + assigned.LandUseID.ToString() +", "+ assigned.Description + "   Impact: " + assigned.Impact);
               
            }

            string filter2 = txtSID.Text;
            listBox5.Items.Clear();
            foreach (site sites in Site.Where(A => A.SiteID.ToString() == (filter2)))
            {
                listBox5.Items.Add(sites.SiteID.ToString() + "  " + sites.SiteName + "  " + sites.Status);

                txtSName.Text = sites.SiteName;
                txtSSatus.Text = sites.Status;

            }
        }

        private void listBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            landuse selectedlanduse = (landuse)listBox4.SelectedItem;

            txtLUID.Text = selectedlanduse.LandUseID.ToString();
            txtLUDescription.Text = selectedlanduse.LandUseDescription;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (txtSHID.Text == "" || txtLUID.Text == "" || cbxLUImpact.Text == "")
            {
                MessageBox.Show("Assign Land Use detail/s are missing", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
                lblReq.Visible = true;
                lblSHList.Visible = true;
                lblLUList.Visible = true;
                lblImpact.Visible = true;

            }

            else
            {
                using (SQLiteConnection cnn = new SQLiteConnection(LoadConnectionString()))
                {

                    int SHID1 = Int32.Parse(txtSHID.Text);
                    int LUID1 = Int32.Parse(txtLUID.Text);

                    string sqlStatment = "SELECT COUNT(*) FROM [Assigned Land Use] WHERE SiteHabitatID like '" + SHID1 + "' AND LandUseID like'" + LUID1 + "' AND Impact like'" + cbxLUImpact.Text + "'";
                    try
                    {
                        cnn.Open();
                        SQLiteCommand cmd = new SQLiteCommand(sqlStatment, cnn);
                        cmd.CommandText = sqlStatment;
                        

                        int SSI = Convert.ToInt32(cmd.ExecuteScalar());

                        if ( SSI == 0)
                        {
                            assignedlanduse L = new assignedlanduse();

                            int SHID = Int32.Parse(txtSHID.Text);
                            int LUID = Int32.Parse(txtLUID.Text);

                            L.SiteHabitatID = SHID;
                            L.LandUseID = LUID;
                            L.Impact = cbxLUImpact.Text;
                            L.Description = txtLUDescription.Text;

                            sqliteDataAccess.SaveAssignedLandUse(L);

                            MessageBox.Show("Land Use Assigned Successfully");

                            txtSHID.Text = "";
                            txtSHName.Text = "";
                            txtSName.Text = "";
                            txtSSatus.Text = "";

                            txtLUID.Text = "";
                            txtLUDescription.Text = "";
                            cbxLUImpact.Text = "";

                            lblReq.Visible = false;
                            lblSHList.Visible = false;
                            lblLUList.Visible = false;
                            lblImpact.Visible = false;


                            LoadSiteHabitatList();

                            LoadAssigendLandUseList();

                            LoadLandUseList();

                            LoadSiteList();
                        }

                        else
                        {
                            MessageBox.Show("Land Use already Assigned to Site Habitat", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            

                            txtLUID.Text = "";
                            txtLUDescription.Text = "";
                            cbxLUImpact.Text = "";

                            lblReq.Visible = false;
                            lblSHList.Visible = false;
                            lblLUList.Visible = false;
                            lblImpact.Visible = false;
                        }
                    }
                    finally
                    {
                        cnn.Close();
                    }

                    

                }

                

            }


        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void Assign_Land_Use_Load(object sender, EventArgs e)
        {
            lblReq.Visible = false;
            lblSHList.Visible = false;
            lblLUList.Visible = false;
            lblImpact.Visible = false;

            listBox2.Visible = false;
            listBox5.Visible = false;
            txtSID.Visible = false;

            txtSHID.Text = "";
            txtSHName.Text = "";
            txtSName.Text = "";
            txtSSatus.Text = "";

            txtLUID.Text = "";
            txtLUDescription.Text = "";
            cbxLUImpact.Text = "";

        }
    }
}
