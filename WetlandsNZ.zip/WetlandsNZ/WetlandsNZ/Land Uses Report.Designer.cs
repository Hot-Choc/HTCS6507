﻿
namespace WetlandsNZ
{
    partial class Land_Uses_Report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtxtReport = new System.Windows.Forms.RichTextBox();
            this.btnreturn = new System.Windows.Forms.Button();
            this.btnDisReport = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // rtxtReport
            // 
            this.rtxtReport.BackColor = System.Drawing.SystemColors.HighlightText;
            this.rtxtReport.Location = new System.Drawing.Point(13, 46);
            this.rtxtReport.Margin = new System.Windows.Forms.Padding(4);
            this.rtxtReport.Name = "rtxtReport";
            this.rtxtReport.ReadOnly = true;
            this.rtxtReport.Size = new System.Drawing.Size(850, 450);
            this.rtxtReport.TabIndex = 1;
            this.rtxtReport.Text = "";
            // 
            // btnreturn
            // 
            this.btnreturn.Location = new System.Drawing.Point(453, 506);
            this.btnreturn.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnreturn.Name = "btnreturn";
            this.btnreturn.Size = new System.Drawing.Size(133, 50);
            this.btnreturn.TabIndex = 28;
            this.btnreturn.Text = "Return";
            this.btnreturn.UseVisualStyleBackColor = true;
            this.btnreturn.Click += new System.EventHandler(this.btnreturn_Click);
            // 
            // btnDisReport
            // 
            this.btnDisReport.Location = new System.Drawing.Point(289, 506);
            this.btnDisReport.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.btnDisReport.Name = "btnDisReport";
            this.btnDisReport.Size = new System.Drawing.Size(133, 50);
            this.btnDisReport.TabIndex = 27;
            this.btnDisReport.Text = "Produce Land Uses Report";
            this.btnDisReport.UseVisualStyleBackColor = true;
            this.btnDisReport.Click += new System.EventHandler(this.btnDisReport_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(357, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(148, 23);
            this.label7.TabIndex = 45;
            this.label7.Text = "Land Uses Report";
            // 
            // Land_Uses_Report
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 561);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnreturn);
            this.Controls.Add(this.btnDisReport);
            this.Controls.Add(this.rtxtReport);
            this.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Land_Uses_Report";
            this.Text = "Land_Uses_Report";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtxtReport;
        private System.Windows.Forms.Button btnreturn;
        private System.Windows.Forms.Button btnDisReport;
        private System.Windows.Forms.Label label7;
    }
}