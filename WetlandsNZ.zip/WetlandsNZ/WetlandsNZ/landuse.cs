﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WetlandsNZ
{
    public class landuse
    {
        public int LandUseID { get; set; }
        public string LandUseDescription { get; set; }
        public string LandUseType { get; set; }

        public string LandUseDetails
        {
            get
            {
                return $"ID:  { LandUseID },   { LandUseDescription }";
            }
        }


    }
}
