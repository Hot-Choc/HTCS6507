﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WetlandsNZ
{
    public partial class Update_Site : Form
    {
        List<site> Site = new List<site>();

        public Update_Site()
        {
            InitializeComponent();

            LoadSiteList();
        }

        private void LoadSiteList()
        {
            Site = sqliteDataAccess.loadSites();

            WireUpSiteList();
        }

        private void WireUpSiteList()
        {
            listBox1.DataSource = null;
            listBox1.DataSource = Site;
            listBox1.DisplayMember = "SiteDetails";
        }



        private void update_Click(object sender, EventArgs e)
        {
            if (txtname.Text == "" || txtarea.Text == "" || txtaltitude.Text == "" || cbxtype.Text == "" || cbxstatus.Text == "")
            {
                MessageBox.Show("Site detail/s are missing", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
                lblReq.Visible = true;
                lbl1.Visible = true;
                lbl2.Visible = true;
                lbl3.Visible = true;
                lbl4.Visible = true;
                lbl5.Visible = true;
                lblList.Visible = true;
            }

            else
            {
                DialogResult DR = MessageBox.Show("Do you wish to UPDATE this LAND USE ?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);

                if(DR == DialogResult.Yes)
                {
                    site s = new site();

                    int ID = Int32.Parse(txtID.Text);

                    s.SiteID = ID;
                    s.SiteName = txtname.Text;
                    s.Area = txtarea.Text;
                    s.Altitude = txtaltitude.Text;
                    s.SiteType = cbxtype.Text;
                    s.Status = cbxstatus.Text;

                    sqliteDataAccess.UpdateSite(s);

                    MessageBox.Show("Site Updated Successfully");

                    txtID.Text = "";
                    txtname.Text = "";
                    txtarea.Text = "";
                    txtaltitude.Text = "";
                    cbxtype.SelectedItem = null;
                    cbxstatus.SelectedItem = null;

                    lblReq.Visible = false;
                    lbl1.Visible = false;
                    lbl2.Visible = false;
                    lbl3.Visible = false;
                    lbl4.Visible = false;
                    lbl5.Visible = false;
                    lblList.Visible = false;

                    LoadSiteList();
                }

                else
                {
                    txtID.Text = "";
                    txtname.Text = "";
                    txtarea.Text = "";
                    txtaltitude.Text = "";
                    cbxtype.SelectedItem = null;
                    cbxstatus.SelectedItem = null;

                    lblReq.Visible = false;
                    lbl1.Visible = false;
                    lbl2.Visible = false;
                    lbl3.Visible = false;
                    lbl4.Visible = false;
                    lbl5.Visible = false;
                    lblList.Visible = false;
                }
                
            }

            

        }

        private void btnreturn_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            site selectedsite = (site)listBox1.SelectedItem;
            txtID.Text = selectedsite.SiteID.ToString();
            txtname.Text = selectedsite.SiteName;
            txtarea.Text = selectedsite.Area;
            txtaltitude.Text = selectedsite.Altitude;
            cbxtype.Text = selectedsite.SiteType;
            cbxstatus.Text = selectedsite.Status;
        }

        private void Update_Site_Load(object sender, EventArgs e)
        {
            lblReq.Visible = false;
            lbl1.Visible = false;
            lbl2.Visible = false;
            lbl3.Visible = false;
            lbl4.Visible = false;
            lbl5.Visible = false;
            lblList.Visible = false;

            txtID.Text = "";
            txtname.Text = "";
            txtarea.Text = "";
            txtaltitude.Text = "";
            cbxtype.SelectedItem = null;
            cbxstatus.SelectedItem = null;
        }
    }
}
