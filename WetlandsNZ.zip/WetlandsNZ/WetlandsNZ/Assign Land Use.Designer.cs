﻿
namespace WetlandsNZ
{
    partial class Assign_Land_Use
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbxLUImpact = new System.Windows.Forms.ComboBox();
            this.lblReq = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.lblSHList = new System.Windows.Forms.Label();
            this.lblImpact = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtLUID = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.txtLUDescription = new System.Windows.Forms.TextBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.txtSHID = new System.Windows.Forms.TextBox();
            this.listBox4 = new System.Windows.Forms.ListBox();
            this.listBox5 = new System.Windows.Forms.ListBox();
            this.txtSID = new System.Windows.Forms.TextBox();
            this.txtSName = new System.Windows.Forms.TextBox();
            this.txtSSatus = new System.Windows.Forms.TextBox();
            this.txtSHName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblLUList = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cbxLUImpact
            // 
            this.cbxLUImpact.FormattingEnabled = true;
            this.cbxLUImpact.Items.AddRange(new object[] {
            "High",
            "Medium",
            "Low"});
            this.cbxLUImpact.Location = new System.Drawing.Point(577, 444);
            this.cbxLUImpact.Margin = new System.Windows.Forms.Padding(4);
            this.cbxLUImpact.Name = "cbxLUImpact";
            this.cbxLUImpact.Size = new System.Drawing.Size(120, 27);
            this.cbxLUImpact.TabIndex = 100;
            // 
            // lblReq
            // 
            this.lblReq.AutoSize = true;
            this.lblReq.ForeColor = System.Drawing.Color.Red;
            this.lblReq.Location = new System.Drawing.Point(576, 492);
            this.lblReq.Name = "lblReq";
            this.lblReq.Size = new System.Drawing.Size(121, 19);
            this.lblReq.TabIndex = 99;
            this.lblReq.Text = "* Required Fields";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(845, 484);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 34);
            this.button1.TabIndex = 98;
            this.button1.Text = "Return";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(704, 484);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(133, 34);
            this.button2.TabIndex = 97;
            this.button2.Text = "Assign Land Use";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(395, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 23);
            this.label4.TabIndex = 96;
            this.label4.Text = "Assign Land Use";
            // 
            // lblSHList
            // 
            this.lblSHList.AutoSize = true;
            this.lblSHList.BackColor = System.Drawing.SystemColors.Control;
            this.lblSHList.ForeColor = System.Drawing.Color.Red;
            this.lblSHList.Location = new System.Drawing.Point(156, 42);
            this.lblSHList.Name = "lblSHList";
            this.lblSHList.Size = new System.Drawing.Size(17, 19);
            this.lblSHList.TabIndex = 95;
            this.lblSHList.Text = "*";
            // 
            // lblImpact
            // 
            this.lblImpact.AutoSize = true;
            this.lblImpact.ForeColor = System.Drawing.Color.Red;
            this.lblImpact.Location = new System.Drawing.Point(553, 447);
            this.lblImpact.Name = "lblImpact";
            this.lblImpact.Size = new System.Drawing.Size(17, 19);
            this.lblImpact.TabIndex = 94;
            this.lblImpact.Text = "*";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(395, 447);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(164, 19);
            this.label10.TabIndex = 92;
            this.label10.Text = "Select Land Use Impact:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(408, 401);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(151, 19);
            this.label11.TabIndex = 91;
            this.label11.Text = "Land Use Description:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(467, 357);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(91, 19);
            this.label12.TabIndex = 90;
            this.label12.Text = "Land Use ID:";
            // 
            // txtLUID
            // 
            this.txtLUID.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtLUID.Location = new System.Drawing.Point(577, 354);
            this.txtLUID.Margin = new System.Windows.Forms.Padding(4);
            this.txtLUID.MaxLength = 3;
            this.txtLUID.Name = "txtLUID";
            this.txtLUID.ReadOnly = true;
            this.txtLUID.Size = new System.Drawing.Size(60, 27);
            this.txtLUID.TabIndex = 89;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 19;
            this.listBox1.Location = new System.Drawing.Point(32, 65);
            this.listBox1.Margin = new System.Windows.Forms.Padding(4);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(400, 156);
            this.listBox1.TabIndex = 88;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // txtLUDescription
            // 
            this.txtLUDescription.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtLUDescription.Location = new System.Drawing.Point(577, 398);
            this.txtLUDescription.Margin = new System.Windows.Forms.Padding(4);
            this.txtLUDescription.MaxLength = 30;
            this.txtLUDescription.Name = "txtLUDescription";
            this.txtLUDescription.ReadOnly = true;
            this.txtLUDescription.Size = new System.Drawing.Size(350, 27);
            this.txtLUDescription.TabIndex = 87;
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 19;
            this.listBox2.Location = new System.Drawing.Point(656, 299);
            this.listBox2.Margin = new System.Windows.Forms.Padding(4);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(61, 23);
            this.listBox2.TabIndex = 101;
            // 
            // listBox3
            // 
            this.listBox3.FormattingEnabled = true;
            this.listBox3.ItemHeight = 19;
            this.listBox3.Location = new System.Drawing.Point(499, 65);
            this.listBox3.Margin = new System.Windows.Forms.Padding(4);
            this.listBox3.Name = "listBox3";
            this.listBox3.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.listBox3.Size = new System.Drawing.Size(360, 156);
            this.listBox3.TabIndex = 102;
            // 
            // txtSHID
            // 
            this.txtSHID.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtSHID.Location = new System.Drawing.Point(143, 229);
            this.txtSHID.Margin = new System.Windows.Forms.Padding(4);
            this.txtSHID.MaxLength = 3;
            this.txtSHID.Name = "txtSHID";
            this.txtSHID.ReadOnly = true;
            this.txtSHID.Size = new System.Drawing.Size(57, 27);
            this.txtSHID.TabIndex = 103;
            // 
            // listBox4
            // 
            this.listBox4.FormattingEnabled = true;
            this.listBox4.ItemHeight = 19;
            this.listBox4.Location = new System.Drawing.Point(28, 351);
            this.listBox4.Margin = new System.Windows.Forms.Padding(4);
            this.listBox4.Name = "listBox4";
            this.listBox4.Size = new System.Drawing.Size(360, 156);
            this.listBox4.TabIndex = 104;
            this.listBox4.SelectedIndexChanged += new System.EventHandler(this.listBox4_SelectedIndexChanged);
            // 
            // listBox5
            // 
            this.listBox5.FormattingEnabled = true;
            this.listBox5.ItemHeight = 19;
            this.listBox5.Location = new System.Drawing.Point(724, 299);
            this.listBox5.Name = "listBox5";
            this.listBox5.Size = new System.Drawing.Size(60, 23);
            this.listBox5.TabIndex = 105;
            // 
            // txtSID
            // 
            this.txtSID.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtSID.Location = new System.Drawing.Point(791, 299);
            this.txtSID.Margin = new System.Windows.Forms.Padding(4);
            this.txtSID.MaxLength = 3;
            this.txtSID.Name = "txtSID";
            this.txtSID.ReadOnly = true;
            this.txtSID.Size = new System.Drawing.Size(30, 27);
            this.txtSID.TabIndex = 106;
            // 
            // txtSName
            // 
            this.txtSName.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtSName.Location = new System.Drawing.Point(115, 264);
            this.txtSName.Margin = new System.Windows.Forms.Padding(4);
            this.txtSName.MaxLength = 30;
            this.txtSName.Name = "txtSName";
            this.txtSName.ReadOnly = true;
            this.txtSName.Size = new System.Drawing.Size(350, 27);
            this.txtSName.TabIndex = 107;
            // 
            // txtSSatus
            // 
            this.txtSSatus.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtSSatus.Location = new System.Drawing.Point(562, 264);
            this.txtSSatus.Margin = new System.Windows.Forms.Padding(4);
            this.txtSSatus.MaxLength = 3;
            this.txtSSatus.Name = "txtSSatus";
            this.txtSSatus.ReadOnly = true;
            this.txtSSatus.Size = new System.Drawing.Size(170, 27);
            this.txtSSatus.TabIndex = 109;
            // 
            // txtSHName
            // 
            this.txtSHName.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtSHName.Location = new System.Drawing.Point(356, 229);
            this.txtSHName.Margin = new System.Windows.Forms.Padding(4);
            this.txtSHName.MaxLength = 30;
            this.txtSHName.Name = "txtSHName";
            this.txtSHName.ReadOnly = true;
            this.txtSHName.Size = new System.Drawing.Size(238, 27);
            this.txtSHName.TabIndex = 110;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 42);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 19);
            this.label1.TabIndex = 111;
            this.label1.Text = "Select Site Habitat:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(495, 42);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(143, 19);
            this.label2.TabIndex = 112;
            this.label2.Text = "Assigned Land Uses:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(28, 232);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(107, 19);
            this.label13.TabIndex = 115;
            this.label13.Text = "Site Habitat ID:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(217, 232);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(131, 19);
            this.label14.TabIndex = 116;
            this.label14.Text = "Site Habitat Name:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(28, 267);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(79, 19);
            this.label15.TabIndex = 117;
            this.label15.Text = "Site Name:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(473, 267);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(81, 19);
            this.label16.TabIndex = 118;
            this.label16.Text = "Site Status:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(27, 328);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(116, 19);
            this.label6.TabIndex = 113;
            this.label6.Text = "Select Land Use:";
            // 
            // lblLUList
            // 
            this.lblLUList.AutoSize = true;
            this.lblLUList.BackColor = System.Drawing.SystemColors.Control;
            this.lblLUList.ForeColor = System.Drawing.Color.Red;
            this.lblLUList.Location = new System.Drawing.Point(139, 328);
            this.lblLUList.Name = "lblLUList";
            this.lblLUList.Size = new System.Drawing.Size(17, 19);
            this.lblLUList.TabIndex = 114;
            this.lblLUList.Text = "*";
            // 
            // Assign_Land_Use
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(964, 531);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.lblLUList);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtSHName);
            this.Controls.Add(this.txtSSatus);
            this.Controls.Add(this.txtSName);
            this.Controls.Add(this.txtSID);
            this.Controls.Add(this.listBox5);
            this.Controls.Add(this.listBox4);
            this.Controls.Add(this.txtSHID);
            this.Controls.Add(this.listBox3);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.cbxLUImpact);
            this.Controls.Add(this.lblReq);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblSHList);
            this.Controls.Add(this.lblImpact);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtLUID);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.txtLUDescription);
            this.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Assign_Land_Use";
            this.Text = "Assign_Land_Use";
            this.Load += new System.EventHandler(this.Assign_Land_Use_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbxLUImpact;
        private System.Windows.Forms.Label lblReq;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblSHList;
        private System.Windows.Forms.Label lblImpact;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtLUID;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox txtLUDescription;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.TextBox txtSHID;
        private System.Windows.Forms.ListBox listBox4;
        private System.Windows.Forms.ListBox listBox5;
        private System.Windows.Forms.TextBox txtSID;
        private System.Windows.Forms.TextBox txtSName;
        private System.Windows.Forms.TextBox txtSSatus;
        private System.Windows.Forms.TextBox txtSHName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblLUList;
    }
}